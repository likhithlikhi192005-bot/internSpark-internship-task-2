#!/usr/bin/env python3
"""
github_repo_explorer.py
========================
Fetches public repository data from the GitHub REST API using `requests`,
parses the JSON response, and lets the user search/filter results by
language, minimum stars, or a keyword in the name/description.

Standard-library + requests only.

Usage examples
--------------
Search GitHub directly (server-side query) and display results:
    python github_repo_explorer.py --query "machine learning" --language python --min-stars 5000

List a specific user's/org's repos, then filter client-side:
    python github_repo_explorer.py --user torvalds --keyword linux

Run with no arguments to be prompted interactively:
    python github_repo_explorer.py
"""

import sys
import argparse
import logging
import requests
from requests.exceptions import RequestException, Timeout, HTTPError, JSONDecodeError

API_BASE = "https://api.github.com"
TIMEOUT_SECONDS = 10
# GitHub's API rejects unauthenticated requests with no User-Agent header (403 Forbidden)
HEADERS = {"User-Agent": "github-repo-explorer-app", "Accept": "application/vnd.github+json"}

# --------------------------------------------------------------------------
# Logging: console output for every fetch/filter step
# --------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(levelname)-8s | %(message)s",
    stream=sys.stdout,
)
log = logging.getLogger("github_repo_explorer")


# --------------------------------------------------------------------------
# Data fetching
# --------------------------------------------------------------------------
def fetch_search_results(query, language=None, min_stars=None, per_page=15):
    """
    Fetch repositories from GitHub's Search API.
    Builds a qualifier string like: "machine learning language:python stars:>5000"
    """
    q_parts = [query] if query else []
    if language:
        q_parts.append(f"language:{language}")
    if min_stars is not None:
        q_parts.append(f"stars:>{min_stars}")

    if not q_parts:
        raise ValueError("At least one of --query, --language, or --min-stars is required for search mode.")

    params = {"q": " ".join(q_parts), "sort": "stars", "order": "desc", "per_page": per_page}
    url = f"{API_BASE}/search/repositories"

    log.info(f"Requesting: {url} params={params}")
    try:
        response = requests.get(url, params=params, headers=HEADERS, timeout=TIMEOUT_SECONDS)
        response.raise_for_status()
    except Timeout:
        log.error("Request timed out while contacting GitHub API.")
        raise
    except HTTPError as e:
        log.error(f"HTTP error from GitHub API: {e}")
        raise
    except RequestException as e:
        log.error(f"Network error contacting GitHub API: {e}")
        raise

    try:
        data = response.json()
    except JSONDecodeError:
        log.error("Failed to parse JSON response from GitHub API.")
        raise

    items = data.get("items", [])

    log.info(f"Received {len(items)} repositories (of {data.get('total_count', 0)} total matches)")
    return items


def fetch_user_repos(username, per_page=30):
    """Fetch all public repositories for a given GitHub user or org."""
    url = f"{API_BASE}/users/{username}/repos"
    params = {"per_page": per_page, "sort": "updated"}

    log.info(f"Requesting: {url} params={params}")
    try:
        response = requests.get(url, params=params, headers=HEADERS, timeout=TIMEOUT_SECONDS)
        response.raise_for_status()
    except Timeout:
        log.error("Request timed out while contacting GitHub API.")
        raise
    except HTTPError as e:
        if response.status_code == 404:
            log.error(f"User '{username}' not found on GitHub.")
        else:
            log.error(f"HTTP error from GitHub API: {e}")
        raise
    except RequestException as e:
        log.error(f"Network error contacting GitHub API: {e}")
        raise

    try:
        data = response.json()
    except JSONDecodeError:
        log.error("Failed to parse JSON response from GitHub API.")
        raise

    log.info(f"Received {len(data)} repositories for user '{username}'")
    return data


# --------------------------------------------------------------------------
# Client-side search / filter (applies on top of already-fetched JSON)
# --------------------------------------------------------------------------
def filter_repos(repos, keyword=None, language=None, min_stars=None):
    filtered = repos

    if keyword:
        kw = keyword.lower()
        filtered = [
            r for r in filtered
            if kw in (r.get("name") or "").lower()
            or kw in (r.get("description") or "").lower()
        ]

    if language:
        lang = language.lower()
        filtered = [r for r in filtered if (r.get("language") or "").lower() == lang]

    if min_stars is not None:
        filtered = [r for r in filtered if r.get("stargazers_count", 0) >= min_stars]

    return filtered


# --------------------------------------------------------------------------
# Display
# --------------------------------------------------------------------------
def display_repos(repos):
    if not repos:
        print("\nNo repositories matched your search/filter criteria.\n")
        return

    print(f"\n{'NAME':<30} {'LANGUAGE':<12} {'STARS':<8} {'DESCRIPTION'}")
    print("-" * 100)
    for r in repos:
        name = r.get("name", "N/A")[:29]
        language = (r.get("language") or "N/A")[:11]
        stars = r.get("stargazers_count", 0)
        description = (r.get("description") or "")[:45]
        print(f"{name:<30} {language:<12} {stars:<8} {description}")
        print(f"    -> {r.get('html_url', '')}")
    print(f"\nTotal displayed: {len(repos)}\n")


# --------------------------------------------------------------------------
# Interactive mode
# --------------------------------------------------------------------------
def interactive_mode():
    print("=== GitHub Repo Explorer (interactive mode) ===")
    mode = input("Search GitHub [1] or fetch a user's repos [2]? ").strip()

    keyword = input("Keyword filter (optional, press Enter to skip): ").strip() or None
    language = input("Language filter (optional, e.g. python): ").strip() or None
    min_stars_raw = input("Minimum stars (optional, e.g. 1000): ").strip()
    min_stars = int(min_stars_raw) if min_stars_raw.isdigit() else None

    try:
        if mode == "2":
            username = input("GitHub username/org: ").strip()
            repos = fetch_user_repos(username)
            repos = filter_repos(repos, keyword=keyword, language=language, min_stars=min_stars)
        else:
            query = keyword or ""
            repos = fetch_search_results(query, language=language, min_stars=min_stars)
        display_repos(repos)
    except (RequestException, ValueError) as e:
        log.error(f"Could not complete request: {e}")


# --------------------------------------------------------------------------
# CLI entry point
# --------------------------------------------------------------------------
def build_parser():
    parser = argparse.ArgumentParser(
        description="Fetch and search/filter GitHub repository data via the REST API."
    )
    parser.add_argument("--query", help="Free-text search term (search mode)")
    parser.add_argument("--user", help="Fetch repos for a specific GitHub user/org instead of searching")
    parser.add_argument("--language", help="Filter by programming language")
    parser.add_argument("--min-stars", type=int, help="Filter by minimum star count")
    parser.add_argument("--keyword", help="Client-side keyword filter on name/description")
    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()

    if len(sys.argv) == 1:
        interactive_mode()
        return

    try:
        if args.user:
            repos = fetch_user_repos(args.user)
            repos = filter_repos(repos, keyword=args.keyword, language=args.language, min_stars=args.min_stars)
        else:
            repos = fetch_search_results(args.query or args.keyword or "", language=args.language, min_stars=args.min_stars)
        display_repos(repos)
    except (RequestException, ValueError) as e:
        log.error(f"Could not complete request: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
